module.exports = {
//url:"mongodb://localhost:27017/uki5notes"
url : "mongodb://piraiyalan:pirai1008@@cluster0-shard-00-00-1vvjg.mongodb.net:27017,cluster0-shard-00-01-1vvjg.mongodb.net:27017,cluster0-shard-00-02-1vvjg.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority"
};
